namespace DotNetTutor.Api.Models;
public record Lesson(int Id, string Title, string Summary, string Content);
