#!/bin/bash

# Script to upload application code to EC2 instance
# Usage: ./upload-to-ec2.sh <instance-ip>

set -e

if [ $# -eq 0 ]; then
    echo "Usage: $0 <instance-ip>"
    echo "Example: $0 54.123.45.67"
    exit 1
fi

INSTANCE_IP=$1
KEY_FILE="dotnet-tutor-key.pem"
REMOTE_USER="ec2-user"
REMOTE_DIR="/opt/dotnet-tutor"

echo "Uploading application code to EC2 instance at $INSTANCE_IP..."

# Check if key file exists
if [ ! -f "$KEY_FILE" ]; then
    echo "Error: Key file $KEY_FILE not found!"
    exit 1
fi

# Create a temporary directory with only the files we need
echo "Preparing files for upload..."
TEMP_DIR=$(mktemp -d)
trap "rm -rf $TEMP_DIR" EXIT

# Copy necessary files
cp -r backend/ $TEMP_DIR/
cp -r frontend/ $TEMP_DIR/
cp -r nginx/ $TEMP_DIR/
cp -r deployment/ $TEMP_DIR/
cp docker-compose.yml $TEMP_DIR/
cp .env $TEMP_DIR/

# Remove unnecessary files to reduce upload size
find $TEMP_DIR -name "node_modules" -type d -exec rm -rf {} + 2>/dev/null || true
find $TEMP_DIR -name "bin" -type d -exec rm -rf {} + 2>/dev/null || true
find $TEMP_DIR -name "obj" -type d -exec rm -rf {} + 2>/dev/null || true
find $TEMP_DIR -name "coverage" -type d -exec rm -rf {} + 2>/dev/null || true
find $TEMP_DIR -name ".git" -type d -exec rm -rf {} + 2>/dev/null || true

echo "Uploading files to EC2 instance..."
# Upload the application files
scp -i "$KEY_FILE" -o StrictHostKeyChecking=no -r $TEMP_DIR/* $REMOTE_USER@$INSTANCE_IP:/tmp/

echo "Setting up application on EC2 instance..."
# Connect to instance and set up the application
ssh -i "$KEY_FILE" -o StrictHostKeyChecking=no $REMOTE_USER@$INSTANCE_IP << 'EOF'
    # Move files to the correct location
    sudo rm -rf /opt/dotnet-tutor/*
    sudo mv /tmp/* /opt/dotnet-tutor/
    
    # Set proper ownership and permissions
    sudo chown -R ec2-user:ec2-user /opt/dotnet-tutor
    sudo chmod +x /opt/dotnet-tutor/deployment/*.sh
    
    # Create data directory if it doesn't exist
    mkdir -p /opt/dotnet-tutor/data
    
    echo "Application files uploaded and configured successfully!"
EOF

echo "Upload completed successfully!"
echo "You can now connect to the instance with:"
echo "ssh -i $KEY_FILE $REMOTE_USER@$INSTANCE_IP"